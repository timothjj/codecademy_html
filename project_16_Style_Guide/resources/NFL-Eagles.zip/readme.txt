This font pack contains the following fonts:

Specific Teams:
	NFL Bears
	NFL Bears Throwback
	NFL Bengals
	NFL Broncos
	NFL Cardinals (2005)
	NFL Colts Throwback
	NFL Cowboys Throwback
	NFL Dolphins
	NFL Eagles
	NFL Falcons
	NFL Jaguars
	NFL Oilers Vintage
	NFL Patriots
	NFL Patriots Vintage
	NFL Rams
	NFL Ravens
	NFL Ravens Vintage
	NFL Steelers
	NFL Texans
	NFL Titans
	NFL Vikings (2006 version)

Varsity Block Variations:
	NFL Varsity Block A (Cardinals, Chiefs, Giants, Jets, Seahawks)
	NFL Varsity Block B (Bills, Panthers, Browns, Cowboys, Lions, Raiders, Redskins)
	NFL Varsity Block C (Packers)
	NFL Varsity Block D (Colts)
	NFL Varsity Block E (Saints)
	NFL Varsity Block F (Chargers)
	NFL Varsity Block G (49ers)
	NFL Varsity Block H (Buccaneers)

Generic Varsity Block Variations:
	Varsity Block A
	Varsity Block B
	Varsity Block C
	Varsity Block D
	Varsity Block Classic A
	Varsity Block Classic B
	Varsity Block Classic C
	Varsity Block Classic D
	Varsity Block Classic Serif A
	Varsity Block Classic Serif B

The numbers & letters were originally created by Nick Whitford (whitedragon22na@yahoo.com) and Jim "jpslapshot" Pericotti.

The TTF fonts were created by Eriq P. Jaffe (eriqjaffe@hotmail.com)

Enjoy!